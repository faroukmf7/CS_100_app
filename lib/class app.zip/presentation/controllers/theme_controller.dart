// lib/presentation/controllers/theme_controller.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';

class ThemeController extends GetxController {
  final _storage = GetStorage();
  final RxBool isDark = false.obs;

  @override
  void onInit() {
    super.onInit();
    isDark.value = _storage.read<bool>(AppConstants.kThemeKey) ?? false;
    _applyTheme();
  }

  void toggleTheme() {
    isDark.value = !isDark.value;
    _storage.write(AppConstants.kThemeKey, isDark.value);
    _applyTheme();
  }

  void _applyTheme() {
    Get.changeTheme(isDark.value ? AppTheme.darkTheme : AppTheme.lightTheme);
  }

  ThemeData get currentTheme => isDark.value ? AppTheme.darkTheme : AppTheme.lightTheme;
}
