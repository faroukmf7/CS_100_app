// lib/presentation/bindings/app_bindings.dart
// ─────────────────────────────────────────
// GetX Dependency Injection — lazily registered at app start.
// Every controller and repository is wired here.
// Add new features here as extension points.
// ─────────────────────────────────────────

import 'package:get/get.dart';
import '../../data/providers/api_provider.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/repositories/class_repository.dart';
import '../../data/repositories/attendance_repository.dart';
import '../controllers/auth_controller.dart';
import '../controllers/class_controller.dart';
import '../controllers/attendance_controller.dart';
import '../controllers/theme_controller.dart';

class AppBindings extends Bindings {
  @override
  void dependencies() {
    // ── Infrastructure (permanent singletons) ──────────────────────────────
    Get.put(ThemeController(), permanent: true);
    Get.lazyPut<ApiProvider>(() => ApiProvider(), fenix: true);

    // ── Repositories ────────────────────────────────────────────────────────
    Get.lazyPut<AuthRepository>(
      () => AuthRepository(Get.find<ApiProvider>()),
      fenix: true,
    );
    Get.lazyPut<ClassRepository>(
      () => ClassRepository(Get.find<ApiProvider>()),
      fenix: true,
    );
    Get.lazyPut<AttendanceRepository>(
      () => AttendanceRepository(Get.find<ApiProvider>()),
      fenix: true,
    );

    // ── Controllers ─────────────────────────────────────────────────────────
    Get.lazyPut<AuthController>(
      () => AuthController(Get.find<AuthRepository>()),
      fenix: true,
    );
    Get.lazyPut<ClassController>(
      () => ClassController(Get.find<ClassRepository>()),
      fenix: true,
    );
    Get.lazyPut<AttendanceController>(
      () => AttendanceController(Get.find<AttendanceRepository>()),
      fenix: true,
    );

    // ── Extension point: add future controllers here ─────────────────────
    // Get.lazyPut<NotificationController>(() => NotificationController());
    // Get.lazyPut<AnalyticsController>(() => AnalyticsController());
  }
}
