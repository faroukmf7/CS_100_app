// lib/data/repositories/class_repository.dart
// ─────────────────────────────────────────
// All class CRUD operations.
// PHP endpoints:
//   GET    /classes/list.php          → [] array of classes
//   POST   /classes/create.php        → class object
//   PUT    /classes/update.php        → {id, ...fields}
//   DELETE /classes/delete.php        → {id}
//   GET    /classes/detail.php?id=X   → single class
// ─────────────────────────────────────────

import '../models/class_model.dart';
import '../providers/api_provider.dart';

class ClassRepository {
  final ApiProvider _api;

  ClassRepository(this._api);

  Future<Map<String, dynamic>> getClasses() async {
    try {
      final response = await _api.get('/classes/list.php');
      final data = response.data;
      if (data['status'] == true) {
        final list = (data['data'] as List)
            .map((e) => ClassModel.fromJson(e as Map<String, dynamic>))
            .toList();
        return {'success': true, 'classes': list};
      }
      return {'success': false, 'message': data['message']};
    } catch (e) {
      return {'success': false, 'message': ApiProvider.handleError(e)};
    }
  }

  Future<Map<String, dynamic>> createClass(ClassModel model) async {
    try {
      final response = await _api.post('/classes/create.php', data: model.toJson());
      final data = response.data;
      if (data['status'] == true) {
        return {
          'success': true,
          'class': ClassModel.fromJson(data['data'] as Map<String, dynamic>),
          'message': data['message'] ?? 'Class created!',
        };
      }
      return {'success': false, 'message': data['message']};
    } catch (e) {
      return {'success': false, 'message': ApiProvider.handleError(e)};
    }
  }

  Future<Map<String, dynamic>> updateClass(ClassModel model) async {
    try {
      final response = await _api.put('/classes/update.php', data: model.toJson());
      final data = response.data;
      if (data['status'] == true) {
        return {'success': true, 'message': data['message'] ?? 'Class updated!'};
      }
      return {'success': false, 'message': data['message']};
    } catch (e) {
      return {'success': false, 'message': ApiProvider.handleError(e)};
    }
  }

  Future<Map<String, dynamic>> deleteClass(int id) async {
    try {
      final response = await _api.delete('/classes/delete.php', data: {'id': id});
      final data = response.data;
      return {'success': data['status'] == true, 'message': data['message']};
    } catch (e) {
      return {'success': false, 'message': ApiProvider.handleError(e)};
    }
  }
}
